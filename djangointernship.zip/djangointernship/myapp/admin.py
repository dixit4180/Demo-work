from django.contrib import admin

from .models import student
from .models import employee

admin.site.register(student)
admin.site.register(employee)


